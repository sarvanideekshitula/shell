#!/bin/bash
echo "Enter filename"
read n
echo "Word"
read w
grep $w $n 
