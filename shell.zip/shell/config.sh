#!/bin/sh
who
echo $LOGNAME
echo $BASH
echo $HOME
echo $OSTYPE
echo $PATH
echo $PWD
echo $SHELL
