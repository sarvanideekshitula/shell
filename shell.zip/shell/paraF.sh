for((i=0;i<$#;i++))
do
  echo ""
done
echo $i
