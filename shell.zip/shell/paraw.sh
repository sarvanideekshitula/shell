i=1
while(($i!=$#))
do
  i=`expr $i + 1`
done
echo "$i"
