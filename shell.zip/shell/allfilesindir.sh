#!/bin/bash
ls ~/Desktop
