#!/bin/bash
ls -S
