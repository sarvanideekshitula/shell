#!/bin/bash
wc -l text.txt
